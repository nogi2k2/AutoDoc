import tempfile
import zipfile
import shutil
from pathlib import Path
from typing import Iterator

class FileResolver:
    """Recursively resolves valid documents from files, directories, and ZIP archives."""
    
    def __init__(self, target_path: str | Path):
        self.target_path = Path(target_path).resolve()
        self.temp_dir = Path(tempfile.mkdtemp(prefix="medrag_parser_"))
        self.valid_exts = {".pdf", ".docx", ".doc", ".xlsx"}

    def _is_valid(self, path: Path) -> bool:
        return path.suffix.lower() in self.valid_exts and not path.name.startswith("~")

    def get_files(self) -> Iterator[Path]:
        """Yields absolute paths to all valid files found."""
        yield from self._process_path(self.target_path)

    def _process_path(self, current_path: Path) -> Iterator[Path]:
        if current_path.is_file():
            if current_path.suffix.lower() == ".zip":
                yield from self._extract_and_process_zip(current_path)
            elif self._is_valid(current_path):
                yield current_path
        elif current_path.is_dir():
            for child in current_path.rglob("*"):
                if child.is_file():
                    if child.suffix.lower() == ".zip":
                        yield from self._extract_and_process_zip(child)
                    elif self._is_valid(child):
                        yield child

    def _extract_and_process_zip(self, zip_path: Path) -> Iterator[Path]:
        """Extracts ZIP to temp folder and processes its contents."""
        extract_path = self.temp_dir / zip_path.stem
        extract_path.mkdir(parents=True, exist_ok=True)
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)
        except zipfile.BadZipFile:
            return  
            
        yield from self._process_path(extract_path)

    def cleanup(self):
        """Deletes the temporary extraction directory."""
        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir, ignore_errors=True)