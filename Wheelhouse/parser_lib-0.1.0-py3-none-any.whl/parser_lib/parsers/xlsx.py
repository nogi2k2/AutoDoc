import re
from pathlib import Path
from collections import deque
from typing import List
import pandas as pd
from openpyxl import load_workbook
from .base import BaseParser

class XlsxParser(BaseParser):
    def _safe_name(self, s: str) -> str:
        return re.sub(r"[^A-Za-z0-9_]+", "_", str(s)).strip("_")

    def parse(self, file_path: Path) -> List[Path]:
        wb = load_workbook(file_path, data_only=True)
        stem = file_path.stem
        out_paths = []
        
        for sheet in wb.sheetnames:
            ws = wb[sheet]
            data = list(ws.values)
            if not data:
                continue
                
            df = pd.DataFrame(data)
            not_null = df.notna()
            visited = set()
            rows, cols = df.shape
            sheet_blocks = []
            
            for r in range(rows):
                for c in range(cols):
                    if not_null.iloc[r, c] and (r, c) not in visited:
                        q = deque([(r, c)])
                        visited.add((r, c))
                        min_r, max_r, min_c, max_c = r, r, c, c
                        
                        while q:
                            curr_r, curr_c = q.popleft()
                            min_r, max_r = min(min_r, curr_r), max(max_r, curr_r)
                            min_c, max_c = min(min_c, curr_c), max(max_c, curr_c)
                            
                            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]:
                                nr, nc = curr_r + dr, curr_c + dc
                                if 0 <= nr < rows and 0 <= nc < cols:
                                    if not_null.iloc[nr, nc] and (nr, nc) not in visited:
                                        visited.add((nr, nc))
                                        q.append((nr, nc))
                                        
                        sub_df = df.iloc[min_r:max_r+1, min_c:max_c+1].dropna(how='all').dropna(axis=1, how='all')
                        if not sub_df.empty:
                            sub_df = sub_df.fillna("")
                            headers = [str(x) if x else f"Col_{i}" for i, x in enumerate(sub_df.iloc[0])]
                            sub_df.columns = headers
                            sub_df = sub_df[1:]
                            if not sub_df.empty:
                                sheet_blocks.append(sub_df.to_markdown(index=False))
                                
            if sheet_blocks:
                out_name = f"{stem}__{self._safe_name(sheet)}.md"
                out_path = self.output_dir / out_name
                final_md = f"## {sheet}\n\n" + "\n\n".join(sheet_blocks)
                out_path.write_text(final_md, encoding="utf-8")
                out_paths.append(out_path)
                
        return out_paths