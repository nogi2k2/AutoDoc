import re
from pathlib import Path
from typing import List
from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions, TableStructureOptions, TableFormerMode
from .base import BaseParser

class PdfParser(BaseParser):
    def __init__(self, output_dir: Path, artifacts_path: str = None):
        super().__init__(output_dir, artifacts_path)
        po = PdfPipelineOptions()
        po.do_ocr = True
        po.do_table_structure = True
        po.table_structure_options = TableStructureOptions(
            mode=TableFormerMode.ACCURATE,
            do_cell_matching=False
        )
        if self.artifacts_path:
            po.artifacts_path = self.artifacts_path
            
        self.converter = DocumentConverter(
            format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=po)}
        )

    def _norm(self, s): 
        return re.sub(r"\s+", " ", (s or "")).strip()

    def _cells_pipe(self, row): 
        return [c.strip() for c in re.split(r"(?<!\\)\|", row.strip().strip("|"))]

    def _rows_equal(self, a, b): 
        if len(a) != len(b): return False
        return all(self._norm(x) == self._norm(y) for x, y in zip(a, b))

    def _dedupe_identical_adjacent(self, rows):
        if not rows: return rows
        out = [rows[0]]
        for r in rows[1:]:
            if not self._rows_equal(out[-1], r):
                out.append(r)
        return out

    def _clean_pdf_markdown(self, md: str) -> str:
        blocks = md.split("\n\n")
        out = []
        for b in blocks:
            lines = [ln.strip() for ln in b.splitlines() if ln.strip()]
            if not lines or not lines[0].startswith("|"):
                out.append(b)
                continue
                
            is_table = all(ln.startswith("|") and ln.endswith("|") for ln in lines)
            if not is_table:
                out.append(b)
                continue
                
            headers = self._cells_pipe(lines[0])
            if len(lines) < 3:
                out.append(b)
                continue
                
            data_rows = [self._cells_pipe(ln) for ln in lines[2:]]
            data_rows = self._dedupe_identical_adjacent(data_rows)
            
            html = ["<table>", "<thead><tr>"]
            for h in headers: html.append(f"<th>{h}</th>")
            html.append("</tr></thead>")
            html.append("<tbody>")
            for r in data_rows:
                html.append("<tr>")
                for c in r: html.append(f"<td>{c}</td>")
                html.append("</tr>")
            html.append("</tbody>")
            html.append("</table>")
            out.append("".join(html))
            
        return "\n\n".join(out)

    def parse(self, file_path: Path) -> List[Path]:
        result = self.converter.convert(str(file_path))
        md = result.document.export_to_markdown()
        md = self._clean_pdf_markdown(md)
        
        out_path = self.output_dir / f"{file_path.stem}.md"
        out_path.write_text(md, encoding="utf-8")
        return [out_path]