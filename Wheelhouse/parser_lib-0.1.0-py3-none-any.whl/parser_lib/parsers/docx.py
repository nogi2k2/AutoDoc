import re
import shutil
from pathlib import Path
from typing import List
from docling.document_converter import DocumentConverter
from .base import BaseParser

class DocxParser(BaseParser):
    def __init__(self, output_dir: Path, artifacts_path: str = None):
        super().__init__(output_dir, artifacts_path)
        self.converter = DocumentConverter()

    def _convert_doc_to_docx(self, src: Path) -> Path:
        import win32com.client
        out_dir = src.parent / "_doc_to_docx"
        out_dir.mkdir(parents=True, exist_ok=True)
        dst = out_dir / f"{src.stem}.docx"

        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0
        try:
            doc = word.Documents.Open(str(src.resolve()))
            doc.SaveAs2(str(dst.resolve()), FileFormat=16)
            doc.Close(False)
        finally:
            word.Quit()
        return dst

    def _clean_docx_markdown(self, md: str) -> str:
        cleaned_lines = []
        for line in md.splitlines():
            line = line.strip()
            if line.startswith("|") and line.endswith("|"):
                cells = [cell.strip() for cell in line.split("|")[1:-1]]
                is_separator = all(re.match(r'^:?-+:?$', c) or c == '' for c in cells if c)
                is_empty_row = all(c == "" for c in cells)
                
                if is_empty_row:
                    continue
                if is_separator:
                    compact_cells = [c if c else "-" for c in cells]
                    cleaned_lines.append("|" + "|".join(compact_cells) + "|")
                else:
                    cleaned_lines.append("| " + " | ".join(cells) + " |")
            else:
                cleaned_lines.append(line)
                
        return re.sub(r'\n{3,}', '\n\n', '\n'.join(cleaned_lines))

    def parse(self, file_path: Path) -> List[Path]:
        work = file_path
        temp_dir = None
        
        if file_path.suffix.lower() == ".doc":
            work = self._convert_doc_to_docx(file_path)
            temp_dir = work.parent

        try:
            result = self.converter.convert(str(work))
            md = result.document.export_to_markdown()
            md = self._clean_docx_markdown(md)
            
            out_path = self.output_dir / f"{file_path.stem}.md"
            out_path.write_text(md, encoding="utf-8")
            return [out_path]
        finally:
            if temp_dir and temp_dir.exists():
                shutil.rmtree(temp_dir, ignore_errors=True)