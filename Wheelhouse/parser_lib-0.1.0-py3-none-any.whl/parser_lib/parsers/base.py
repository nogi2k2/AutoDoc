from abc import ABC, abstractmethod
from pathlib import Path
from typing import List

class BaseParser(ABC):
    def __init__(self, output_dir: Path, artifacts_path: str = None):
        self.output_dir = output_dir
        self.artifacts_path = artifacts_path

    @abstractmethod
    def parse(self, file_path: Path) -> List[Path]:
        pass