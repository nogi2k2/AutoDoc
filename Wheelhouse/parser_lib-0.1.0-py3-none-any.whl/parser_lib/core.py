from pathlib import Path
from typing import List
from .utils.resolver import FileResolver
from .parsers.pdf import PdfParser
from .parsers.docx import DocxParser
from .parsers.xlsx import XlsxParser

class DocumentParser:
    def __init__(self, output_dir: str, artifacts_path: str = None):
        self.output_dir = Path(output_dir).resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.artifacts_path = artifacts_path
        
        self.parsers = {
            ".pdf": PdfParser(self.output_dir, self.artifacts_path),
            ".docx": DocxParser(self.output_dir, self.artifacts_path),
            ".doc": DocxParser(self.output_dir, self.artifacts_path),
            ".xlsx": XlsxParser(self.output_dir, self.artifacts_path)
        }

    def parse(self, target_path: str) -> List[Path]:
        resolver = FileResolver(target_path)
        generated_files = []
        
        try:
            for file_path in resolver.get_files():
                ext = file_path.suffix.lower()
                if ext in self.parsers:
                    parser = self.parsers[ext]
                    out_paths = parser.parse(file_path)
                    generated_files.extend(out_paths)
        finally:
            resolver.cleanup()
            
        return generated_files